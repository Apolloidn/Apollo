# Discord Bot Professional 🤖

A professional Discord bot built with Node.js and discord.js v14, featuring a modular command handler system, automatic slash command registration, leveling system, and comprehensive moderation tools.

## ✨ Features

- 🔄 **Automatic Command Registration** - Commands are auto-registered to Discord
- 📁 **Modular Structure** - Easy to organize and maintain
- 🛡️ **Error Handling** - Comprehensive error handling
- 🎯 **28 Commands** - Across 4 categories
- 💬 **Auto-Reply** - Responds to greetings automatically
- 📊 **Leveling System** - XP & level tracking with JSON storage
- ⚠️ **Warning System** - Track user warnings persistently
- 🔒 **Anti-Raid Protection** - Automatic protection against join spam
- 🎭 **Review System** - Users can rate and review
- ✅ **Verification System** - Account age + button verification

## 📋 Commands

### Basic Commands (5)
- `/ping` - Check bot latency
- `/serverinfo` - Display server information
- `/userinfo` - Display user information
- `/avatar` - Show user's avatar
- `/help` - Show all available commands

### Moderation Commands (9)
- `/kick` - Kick a member
- `/ban` - Ban a member
- `/warn` - Warn a member (saved to JSON)
- `/warnings` - View user warnings
- `/clearwarn` - Clear user warnings
- `/mute` - Mute member with duration
- `/unmute` - Unmute member
- `/purge` - Delete messages in bulk
- `/lock` - Lock channel
- `/unlock` - Unlock channel

### Fun Commands (3)
- `/8ball` - Ask the magic 8-ball
- `/roll` - Roll a dice
- `/coinflip` - Flip a coin

### Utility Commands (11)
- `/poll` - Create a poll
- `/uptime` - Bot uptime
- `/botinfo` - Bot information
- `/serverstats` - Server statistics
- `/qr` - Generate QR code from text
- `/suggest` - Send suggestion to staff channel
- `/bugreport` - Report bugs to staff channel
- `/review` - Rate server (1-5 stars)
- `/verify` - Verify account (7-day age + button check)
- `/level` - View your level/XP

## 🚀 Setup

1. **Get Bot Token**
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Create a new application
   - Go to "Bot" section and create a bot
   - **Enable all 3 Privileged Gateway Intents:**
     - ✅ PRESENCE INTENT
     - ✅ SERVER MEMBERS INTENT
     - ✅ MESSAGE CONTENT INTENT
   - Copy the token

2. **Set Environment Variables**
   - Set `DISCORD_TOKEN` with your bot token
   - Set `CLIENT_ID` with your application ID

3. **Invite Bot to Server**
   - Use this URL format:
   ```
   https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&scope=bot%20applications.commands
   ```

4. **Run the Bot**
   - Click the "Run" button in Replit
   - Bot will automatically register commands and go online!

## 🎮 Systems

### Leveling System
- Users gain 10-20 XP per message (1 minute cooldown)
- Level up every 100 XP
- Data saved to `data/levels.json`
- Auto-announces level ups
- Use `/level` to check progress

### Warning System
- Staff can warn users with `/warn`
- Warnings saved persistently to `data/warnings.json`
- View warnings with `/warnings`
- Clear all warnings with `/clearwarn`

### Anti-Raid Protection
- Detects if 5+ members join within 10 seconds
- Auto-kicks accounts younger than 7 days during raids
- Protects server from mass bot joins

### Verification System
- Users must have account older than 7 days
- Button verification to prevent bots
- Auto-assigns verified role
- Welcome message in verify channel

### Review System
- Users can rate server 1-5 stars
- Include feedback text
- Saved to `data/reviews.json`

## 🔧 Adding New Commands

It's super easy to add new commands:

1. Create a new `.js` file in `src/commands/[category]/`
2. Use this template:

```javascript
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('yourcommand')
    .setDescription('Your command description'),

  async execute(interaction) {
    await interaction.reply('Your response!');
  },
};
```

3. Restart the bot - that's it! The command will be automatically loaded and registered.

## 📁 Project Structure

```
├── index.js              # Main bot file
├── src/
│   ├── commands/         # All command files
│   │   ├── basic/        # Basic commands
│   │   ├── moderation/   # Moderation commands
│   │   ├── fun/          # Fun commands
│   │   └── utility/      # Utility commands
│   ├── events/           # Event handlers
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   ├── messageCreate.js (with leveling)
│   │   └── guildMemberAdd.js (anti-raid)
│   └── utils/            # Utility functions
│       ├── errorHandler.js
│       ├── embedBuilder.js
│       ├── logger.js
│       └── storage.js (JSON storage)
├── data/                 # JSON data storage
│   ├── warnings.json
│   ├── levels.json
│   ├── tickets.json
│   └── reviews.json
├── package.json
└── .env                  # Environment variables
```

## 🛠️ Built With

- [Node.js](https://nodejs.org/) - JavaScript runtime
- [discord.js v14](https://discord.js.org/) - Discord API library
- [dotenv](https://www.npmjs.com/package/dotenv) - Environment variable management
- [qrcode](https://www.npmjs.com/package/qrcode) - QR code generation
- [moment](https://www.npmjs.com/package/moment) - Date/time handling

## 📝 Configuration

You can customize these settings by changing the IDs in the code:

- **Verified Role ID:** `1437602180076142633` (in `/verify` command)
- **Staff Role ID:** `1437602138854391850` (for `/mute`, `/unmute`)
- **Suggestion Channel:** `1440139961394397395` (for `/suggest`, `/bugreport`)
- **Verify Channel:** `1440141025241862195` (welcome messages)

## 📊 Data Storage

All data is stored in JSON files in the `data/` directory:
- Warnings are persistent across restarts
- Levels/XP are saved automatically
- Reviews are logged with timestamps
- Tickets track claimed status

## 📝 License

This project is open source and available under the MIT License.
