# 🚀 Setup Guide untuk Discord Bot

## Langkah 1: Buat Discord Application

1. Buka [Discord Developer Portal](https://discord.com/developers/applications)
2. Klik tombol **"New Application"**
3. Beri nama aplikasi kamu (contoh: "My Awesome Bot")
4. Klik **"Create"**

## Langkah 2: Buat Bot

1. Di sidebar kiri, klik **"Bot"**
2. Klik tombol **"Add Bot"** kemudian **"Yes, do it!"**
3. Bot kamu sekarang sudah dibuat! ✅

## Langkah 3: Enable Intents (PENTING!)

Ini sangat penting! Tanpa ini, bot tidak akan bisa jalan.

1. Masih di halaman **"Bot"**, scroll ke bawah ke bagian **"Privileged Gateway Intents"**
2. Enable 3 intents ini:
   - ✅ **PRESENCE INTENT**
   - ✅ **SERVER MEMBERS INTENT**
   - ✅ **MESSAGE CONTENT INTENT** (Yang paling penting!)
3. Klik **"Save Changes"**

## Langkah 4: Dapatkan Token & Client ID

### Client ID:
1. Di sidebar kiri, klik **"General Information"**
2. Copy **"Application ID"** - ini adalah CLIENT_ID kamu
3. Simpan di tempat yang aman

### Bot Token:
1. Di sidebar kiri, klik **"Bot"**
2. Di bagian **"Token"**, klik **"Reset Token"**
3. Klik **"Yes, do it!"**
4. Copy token yang muncul (ini hanya muncul sekali!)
5. Simpan di tempat yang aman - ini adalah DISCORD_TOKEN kamu

⚠️ **JANGAN PERNAH** share token kamu ke orang lain!

## Langkah 5: Set Environment Variables di Replit

Token dan Client ID sudah kamu set melalui Replit Secrets. Pastikan:
- `DISCORD_TOKEN` = Token bot kamu
- `CLIENT_ID` = Application ID kamu

## Langkah 6: Invite Bot ke Server

1. Di Discord Developer Portal, masih di aplikasi kamu
2. Di sidebar kiri, klik **"OAuth2"** → **"URL Generator"**
3. Di **"Scopes"**, centang:
   - ✅ `bot`
   - ✅ `applications.commands`
4. Di **"Bot Permissions"**, centang:
   - ✅ Administrator (atau pilih permission spesifik yang kamu butuhkan)
5. Copy URL yang muncul di bawah
6. Paste URL tersebut di browser
7. Pilih server yang ingin kamu tambahkan bot nya
8. Klik **"Authorize"**

## Langkah 7: Jalankan Bot

1. Di Replit, klik tombol **"Run"** atau restart workflow "Discord Bot"
2. Tunggu beberapa detik
3. Jika berhasil, kamu akan melihat:
   ```
   ✅ Loaded command: ping
   ✅ Loaded command: help
   ... (dan command lainnya)
   🚀 Bot is ready! Logged in as YourBot#1234
   ```

## ✅ Testing

Coba command ini di server Discord kamu:
- `/ping` - Harus reply dengan latency
- `/help` - Harus show semua commands
- Ketik "halo" di chat (tanpa /) - Bot harus reply

## ❌ Troubleshooting

### Error: "Used disallowed intents"
**Solusi:** Kamu belum enable intents di Discord Developer Portal. Ulangi Langkah 3.

### Error: "Invalid token"
**Solusi:** 
- Pastikan DISCORD_TOKEN di Replit Secrets sudah benar
- Token tidak boleh ada spasi di awal/akhir
- Coba reset token lagi di Developer Portal

### Bot tidak respond ke commands
**Solusi:**
- Pastikan bot sudah di-invite dengan `applications.commands` scope
- Wait beberapa menit untuk slash commands ter-register
- Restart Discord app kamu
- Kick dan invite ulang bot ke server

### Bot tidak reply saat ketik "halo"
**Solusi:**
- Pastikan MESSAGE_CONTENT intent sudah enabled
- Restart bot di Replit

## 📚 Dokumentasi Tambahan

- [Discord.js Guide](https://discordjs.guide/)
- [Discord Developer Documentation](https://discord.com/developers/docs)

## 🆘 Butuh Bantuan?

Jika masih ada masalah, cek:
1. Console logs di Replit untuk error messages
2. Pastikan semua environment variables sudah set
3. Pastikan bot punya permissions yang cukup di server
