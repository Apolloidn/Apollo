const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

client.commands = new Collection();

function loadCommands(dir = 'src/commands') {
  const commandFiles = [];
  
  function readDirectory(directory) {
    const items = fs.readdirSync(directory);
    
    for (const item of items) {
      const itemPath = path.join(directory, item);
      const stat = fs.statSync(itemPath);
      
      if (stat.isDirectory()) {
        readDirectory(itemPath);
      } else if (item.endsWith('.js')) {
        commandFiles.push(itemPath);
      }
    }
  }
  
  readDirectory(dir);
  
  for (const file of commandFiles) {
    const command = require(`./${file}`);
    if ('data' in command && 'execute' in command) {
      client.commands.set(command.data.name, command);
      console.log(`✅ Loaded command: ${command.data.name}`);
    } else {
      console.log(`⚠️  Warning: ${file} is missing required "data" or "execute" property.`);
    }
  }
}

function loadEvents() {
  const eventsPath = path.join(__dirname, 'src/events');
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    const event = require(filePath);
    
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, client));
    } else {
      client.on(event.name, (...args) => event.execute(...args, client));
    }
    console.log(`✅ Loaded event: ${event.name}`);
  }
}

async function registerCommands() {
  const commands = [];
  client.commands.forEach(command => {
    commands.push(command.data.toJSON());
  });

  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    console.log(`🔄 Started refreshing ${commands.length} application (/) commands.`);

    const data = await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands },
    );

    console.log(`✅ Successfully reloaded ${data.length} application (/) commands.`);
  } catch (error) {
    console.error('❌ Error registering commands:', error);
  }
}

loadCommands();
loadEvents();

client.once('ready', async (client) => {
  await registerCommands();
});

client.login(process.env.DISCORD_TOKEN).catch(err => {
  console.error('❌ Failed to login:', err.message);
  
  if (err.message.includes('disallowed intents')) {
    console.log('\n⚠️  INTENT ERROR: You need to enable intents in Discord Developer Portal!');
    console.log('📋 Follow these steps:');
    console.log('   1. Go to https://discord.com/developers/applications');
    console.log('   2. Select your application');
    console.log('   3. Go to "Bot" section in the left sidebar');
    console.log('   4. Scroll down to "Privileged Gateway Intents"');
    console.log('   5. Enable these intents:');
    console.log('      ✅ PRESENCE INTENT');
    console.log('      ✅ SERVER MEMBERS INTENT');
    console.log('      ✅ MESSAGE CONTENT INTENT');
    console.log('   6. Click "Save Changes"');
    console.log('   7. Restart this bot\n');
  } else {
    console.log('\n⚠️  Please make sure DISCORD_TOKEN and CLIENT_ID are set correctly.');
  }
});
