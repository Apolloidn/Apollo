const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roll')
    .setDescription('Roll dice')
    .addIntegerOption(option =>
      option.setName('sides')
        .setDescription('Jumlah sisi dice (default: 6)')
        .setRequired(false)
        .setMinValue(2)
        .setMaxValue(100)
    ),

  async execute(interaction) {
    const sides = interaction.options.getInteger('sides') || 6;
    const result = Math.floor(Math.random() * sides) + 1;

    const embed = infoEmbed('🎲 Dice Roll', 
      `Kamu melempar dice dengan **${sides}** sisi!\n🎯 Hasilnya: **${result}**`
    );

    await interaction.reply({ embeds: [embed] });
  },
};
