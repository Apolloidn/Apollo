const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Lempar koin'),

  async execute(interaction) {
    const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
    const emoji = result === 'Heads' ? '🪙' : '💰';

    const embed = infoEmbed('🪙 Coin Flip', 
      `Kamu melempar koin...\n${emoji} Hasilnya: **${result}**`
    );

    await interaction.reply({ embeds: [embed] });
  },
};
