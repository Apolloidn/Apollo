const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Tanya bola ajaib')
    .addStringOption(option =>
      option.setName('question')
        .setDescription('Pertanyaan kamu')
        .setRequired(true)
    ),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const responses = [
      'Ya, pasti!',
      'Sepertinya iya.',
      'Mungkin.',
      'Tidak yakin.',
      'Coba lagi nanti.',
      'Sepertinya tidak.',
      'Tidak, pasti tidak!',
      'Jangan harap!',
      'Absolutely!',
      'Kemungkinan besar iya.',
      'Aku rasa tidak.',
    ];

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];

    const embed = infoEmbed('🎱 Magic 8-Ball', 
      `**Pertanyaan:** ${question}\n**Jawaban:** ${randomResponse}`
    );

    await interaction.reply({ embeds: [embed] });
  },
};
