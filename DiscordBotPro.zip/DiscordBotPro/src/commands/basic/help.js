const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Tampilkan semua commands yang tersedia'),

  async execute(interaction) {
    const embed = createEmbed({
      color: '#5865F2',
      title: '📚 Help - Daftar Commands',
      description: 'Berikut adalah semua command yang tersedia:',
      fields: [
        {
          name: '📝 Basic Commands',
          value: '`/ping` - Cek latency bot\n`/serverinfo` - Info server\n`/userinfo` - Info user\n`/avatar` - Lihat avatar user\n`/help` - Command ini',
          inline: false,
        },
        {
          name: '🛡️ Moderation Commands',
          value: '`/kick` - Kick member\n`/ban` - Ban member\n`/warn` - Beri warning\n`/warnings` - Lihat warnings\n`/clearwarn` - Hapus warnings\n`/mute` - Mute member\n`/unmute` - Unmute member\n`/purge` - Hapus pesan\n`/lock` - Kunci channel\n`/unlock` - Buka channel',
          inline: false,
        },
        {
          name: '🎮 Fun Commands',
          value: '`/8ball` - Tanya bola ajaib\n`/roll` - Roll dice\n`/coinflip` - Lempar koin',
          inline: false,
        },
        {
          name: '🔧 Utility Commands',
          value: '`/poll` - Buat polling\n`/uptime` - Bot uptime\n`/botinfo` - Info bot\n`/serverstats` - Statistik server\n`/qr` - Generate QR code\n`/suggest` - Kirim saran\n`/bugreport` - Report bug\n`/review` - Beri rating\n`/verify` - Verifikasi akun\n`/level` - Lihat level',
          inline: false,
        },
      ],
      footer: { text: 'Bot dibuat dengan ❤️ menggunakan discord.js v14' },
    });

    await interaction.reply({ embeds: [embed] });
  },
};
