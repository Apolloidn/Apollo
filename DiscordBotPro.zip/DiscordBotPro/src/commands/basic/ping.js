const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Cek latency bot'),

  async execute(interaction) {
    const apiLatency = Math.round(interaction.client.ws.ping);
    
    await interaction.deferReply();
    const sent = await interaction.fetchReply();
    const latency = sent.createdTimestamp - interaction.createdTimestamp;

    const embed = infoEmbed('🏓 Pong!', 
      `**Latency:** ${latency}ms\n**API Latency:** ${apiLatency}ms`
    );

    await interaction.editReply({ embeds: [embed] });
  },
};
