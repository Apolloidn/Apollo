const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Tampilkan informasi user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin dilihat info nya')
        .setRequired(false)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id);

    const roles = member.roles.cache
      .filter(role => role.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position)
      .map(role => role.toString())
      .slice(0, 10);

    const embed = createEmbed({
      color: member.displayHexColor || '#5865F2',
      title: `👤 ${user.tag}`,
      thumbnail: user.displayAvatarURL({ dynamic: true, size: 256 }),
      fields: [
        { name: '🆔 User ID', value: user.id, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: `🎭 Roles [${roles.length}]`, value: roles.length ? roles.join(', ') : 'None', inline: false },
        { name: '🎨 Highest Role', value: member.roles.highest.toString(), inline: true },
        { name: '📱 Status', value: member.presence?.status || 'offline', inline: true },
      ],
      footer: { text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() },
    });

    await interaction.reply({ embeds: [embed] });
  },
};
