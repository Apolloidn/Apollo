const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Tampilkan avatar user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin dilihat avatar nya')
        .setRequired(false)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const avatarURL = user.displayAvatarURL({ dynamic: true, size: 1024 });

    const embed = createEmbed({
      color: '#5865F2',
      title: `🖼️ Avatar ${user.tag}`,
      description: `[Download](${avatarURL})`,
      image: avatarURL,
      footer: { text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() },
    });

    await interaction.reply({ embeds: [embed] });
  },
};
