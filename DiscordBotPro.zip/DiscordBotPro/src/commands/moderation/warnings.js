const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createEmbed, errorEmbed } = require('../../utils/embedBuilder');
const { warnings } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Lihat daftar warning user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin dilihat warning nya')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const userWarnings = warnings.getUser(target.id, interaction.guild.id);

    if (userWarnings.length === 0) {
      return interaction.reply({ 
        embeds: [errorEmbed(`${target.tag} tidak memiliki warning.`)], 
        ephemeral: true 
      });
    }

    const warningList = userWarnings.map((w, index) => {
      const date = new Date(w.timestamp).toLocaleString('id-ID');
      return `**${index + 1}.** ${w.reason}\n└ Moderator: <@${w.moderator}>\n└ Tanggal: ${date}`;
    }).join('\n\n');

    const embed = createEmbed({
      color: '#FF9900',
      title: `⚠️ Warnings - ${target.tag}`,
      description: warningList,
      footer: { text: `Total: ${userWarnings.length} warning(s)` },
    });

    await interaction.reply({ embeds: [embed] });
  },
};
