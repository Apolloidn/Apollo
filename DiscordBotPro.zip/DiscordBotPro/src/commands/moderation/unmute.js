const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmute member (Staff only)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin di-unmute')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(target.id);

    const STAFF_ROLE_ID = '1437602138854391850';
    if (!interaction.member.roles.cache.has(STAFF_ROLE_ID)) {
      return interaction.reply({ 
        embeds: [errorEmbed('Hanya staff yang bisa menggunakan command ini!')], 
        ephemeral: true 
      });
    }

    if (!member.isCommunicationDisabled()) {
      return interaction.reply({ 
        embeds: [errorEmbed(`${target.tag} tidak sedang di-mute!`)], 
        ephemeral: true 
      });
    }

    try {
      await member.timeout(null);
      await interaction.reply({ 
        embeds: [successEmbed(`✅ ${target.tag} telah di-unmute!`)] 
      });
    } catch (error) {
      console.error('Error unmuting member:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal unmute member!')], 
        ephemeral: true 
      });
    }
  },
};
