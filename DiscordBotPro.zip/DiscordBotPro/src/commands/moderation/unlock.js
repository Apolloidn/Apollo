const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Buka kunci channel ini')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({ 
        embeds: [errorEmbed('Kamu tidak punya permission untuk membuka channel!')], 
        ephemeral: true 
      });
    }

    try {
      await interaction.channel.permissionOverwrites.edit(interaction.guild.id, {
        SendMessages: null,
      });

      await interaction.reply({ 
        embeds: [successEmbed('🔓 Channel telah dibuka!')] 
      });
    } catch (error) {
      console.error('Error unlocking channel:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal membuka channel!')], 
        ephemeral: true 
      });
    }
  },
};
