const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute member (Staff only)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin di-mute')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('duration')
        .setDescription('Durasi mute dalam menit')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(40320)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Alasan mute')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const duration = interaction.options.getInteger('duration');
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan';
    const member = await interaction.guild.members.fetch(target.id);

    const STAFF_ROLE_ID = '1437602138854391850';
    if (!interaction.member.roles.cache.has(STAFF_ROLE_ID)) {
      return interaction.reply({ 
        embeds: [errorEmbed('Hanya staff yang bisa menggunakan command ini!')], 
        ephemeral: true 
      });
    }

    if (!member.moderatable) {
      return interaction.reply({ 
        embeds: [errorEmbed('Tidak bisa mute member ini!')], 
        ephemeral: true 
      });
    }

    if (member.id === interaction.user.id) {
      return interaction.reply({ 
        embeds: [errorEmbed('Kamu tidak bisa mute diri sendiri!')], 
        ephemeral: true 
      });
    }

    try {
      await member.timeout(duration * 60 * 1000, reason);
      await interaction.reply({ 
        embeds: [successEmbed(`✅ ${target.tag} telah di-mute selama ${duration} menit!\n**Reason:** ${reason}`)] 
      });
    } catch (error) {
      console.error('Error muting member:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal mute member!')], 
        ephemeral: true 
      });
    }
  },
};
