const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Kunci channel ini')
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Alasan mengunci channel')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan';

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({ 
        embeds: [errorEmbed('Kamu tidak punya permission untuk mengunci channel!')], 
        ephemeral: true 
      });
    }

    try {
      await interaction.channel.permissionOverwrites.edit(interaction.guild.id, {
        SendMessages: false,
      });

      await interaction.reply({ 
        embeds: [successEmbed(`🔒 Channel telah dikunci!\n**Reason:** ${reason}`)] 
      });
    } catch (error) {
      console.error('Error locking channel:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal mengunci channel!')], 
        ephemeral: true 
      });
    }
  },
};
