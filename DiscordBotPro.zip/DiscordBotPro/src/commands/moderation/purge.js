const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Hapus pesan dalam jumlah tertentu (Staff only)')
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Jumlah pesan yang akan dihapus (1-100)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({ 
        embeds: [errorEmbed('Kamu tidak punya permission untuk menghapus pesan!')], 
        ephemeral: true 
      });
    }

    try {
      const deleted = await interaction.channel.bulkDelete(amount, true);
      
      const reply = await interaction.reply({ 
        embeds: [successEmbed(`✅ Berhasil menghapus ${deleted.size} pesan!`)],
        fetchReply: true
      });

      setTimeout(() => {
        reply.delete().catch(() => {});
      }, 5000);
    } catch (error) {
      console.error('Error purging messages:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal menghapus pesan! Pastikan pesan tidak lebih dari 14 hari.')], 
        ephemeral: true 
      });
    }
  },
};
