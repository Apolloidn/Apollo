const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');
const { warnings } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearwarn')
    .setDescription('Hapus semua warning user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin dihapus warning nya')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const userWarnings = warnings.getUser(target.id, interaction.guild.id);

    if (userWarnings.length === 0) {
      return interaction.reply({ 
        embeds: [errorEmbed(`${target.tag} tidak memiliki warning.`)], 
        ephemeral: true 
      });
    }

    warnings.clear(target.id, interaction.guild.id);

    await interaction.reply({ 
      embeds: [successEmbed(`✅ Semua warning ${target.tag} telah dihapus!`)] 
    });
  },
};
