const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');
const { warnings } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Beri warning ke member')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin di-warn')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Alasan warning')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ embeds: [errorEmbed('Kamu tidak punya permission untuk warn members!')], ephemeral: true });
    }

    if (target.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed('Kamu tidak bisa warn diri sendiri!')], ephemeral: true });
    }

    try {
      const warnCount = warnings.add(target.id, interaction.guild.id, reason, interaction.user.id);

      await target.send({
        embeds: [errorEmbed(`⚠️ Kamu mendapat warning di **${interaction.guild.name}**\n**Reason:** ${reason}\n**Dari:** ${interaction.user.tag}\n**Total Warnings:** ${warnCount}`)]
      }).catch(() => {});

      await interaction.reply({ embeds: [successEmbed(`✅ ${target.tag} telah di-warn!\n**Reason:** ${reason}\n**Total Warnings:** ${warnCount}`)] });
    } catch (error) {
      await interaction.reply({ embeds: [errorEmbed('Gagal warn member!')], ephemeral: true });
    }
  },
};
