const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick member dari server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin di-kick')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Alasan kick')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Tidak ada alasan';
    const member = await interaction.guild.members.fetch(target.id);

    if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ embeds: [errorEmbed('Kamu tidak punya permission untuk kick members!')], ephemeral: true });
    }

    if (!member.kickable) {
      return interaction.reply({ embeds: [errorEmbed('Tidak bisa kick member ini!')], ephemeral: true });
    }

    if (member.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed('Kamu tidak bisa kick diri sendiri!')], ephemeral: true });
    }

    try {
      await member.kick(reason);
      await interaction.reply({ embeds: [successEmbed(`✅ ${target.tag} telah di-kick!\n**Reason:** ${reason}`)] });
    } catch (error) {
      await interaction.reply({ embeds: [errorEmbed('Gagal kick member!')], ephemeral: true });
    }
  },
};
