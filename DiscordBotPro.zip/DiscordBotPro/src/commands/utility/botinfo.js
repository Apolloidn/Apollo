const { SlashCommandBuilder, version } = require('discord.js');
const { createEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('Tampilkan informasi bot'),

  async execute(interaction) {
    const totalSeconds = Math.floor(interaction.client.uptime / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    const embed = createEmbed({
      color: '#5865F2',
      title: '🤖 Bot Information',
      thumbnail: interaction.client.user.displayAvatarURL(),
      fields: [
        { name: '📝 Bot Name', value: interaction.client.user.tag, inline: true },
        { name: '🆔 Bot ID', value: interaction.client.user.id, inline: true },
        { name: '📊 Servers', value: `${interaction.client.guilds.cache.size}`, inline: true },
        { name: '👥 Users', value: `${interaction.client.users.cache.size}`, inline: true },
        { name: '💬 Commands', value: `${interaction.client.commands.size}`, inline: true },
        { name: '📡 Ping', value: `${Math.round(interaction.client.ws.ping)}ms`, inline: true },
        { name: '⏰ Uptime', value: `${days}d ${hours}h ${minutes}m`, inline: true },
        { name: '📚 Discord.js', value: `v${version}`, inline: true },
        { name: '💻 Node.js', value: process.version, inline: true },
      ],
      footer: { text: 'Bot dibuat dengan ❤️ menggunakan discord.js' },
    });

    await interaction.reply({ embeds: [embed] });
  },
};
