const { SlashCommandBuilder } = require('discord.js');
const { createEmbed, successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Kirim saran untuk server')
    .addStringOption(option =>
      option.setName('suggestion')
        .setDescription('Saran kamu')
        .setRequired(true)
    ),

  async execute(interaction) {
    const suggestion = interaction.options.getString('suggestion');
    const SUGGESTION_CHANNEL_ID = '1440139961394397395';

    try {
      const channel = await interaction.client.channels.fetch(SUGGESTION_CHANNEL_ID);
      
      if (!channel) {
        return interaction.reply({ 
          embeds: [errorEmbed('Channel suggestion tidak ditemukan!')], 
          ephemeral: true 
        });
      }

      const embed = createEmbed({
        color: '#00FF00',
        title: '💡 Suggestion Baru',
        description: suggestion,
        fields: [
          { name: '👤 Dari', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
          { name: '📅 Waktu', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
        ],
        footer: { text: `Server: ${interaction.guild.name}` },
      });

      const message = await channel.send({ embeds: [embed] });
      await message.react('👍');
      await message.react('👎');

      await interaction.reply({ 
        embeds: [successEmbed('✅ Suggestion kamu telah dikirim! Terima kasih atas feedback nya.')], 
        ephemeral: true 
      });
    } catch (error) {
      console.error('Error sending suggestion:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal mengirim suggestion!')], 
        ephemeral: true 
      });
    }
  },
};
