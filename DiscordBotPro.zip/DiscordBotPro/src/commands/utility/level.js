const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embedBuilder');
const { levels } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('level')
    .setDescription('Lihat level kamu atau user lain')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User yang ingin dilihat level nya')
        .setRequired(false)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const userData = levels.getUser(target.id, interaction.guild.id);

    const xpNeeded = (userData.level + 1) * 100;
    const progress = ((userData.xp % 100) / 100) * 20;
    const progressBar = '█'.repeat(Math.floor(progress)) + '░'.repeat(20 - Math.floor(progress));

    const embed = createEmbed({
      color: '#5865F2',
      title: `📊 Level - ${target.tag}`,
      thumbnail: target.displayAvatarURL({ dynamic: true }),
      fields: [
        { name: '🎯 Level', value: `${userData.level}`, inline: true },
        { name: '⭐ Total XP', value: `${userData.xp}`, inline: true },
        { name: '💬 Messages', value: `${userData.messages}`, inline: true },
        { name: '📈 Progress', value: `${progressBar}\n${userData.xp % 100}/${xpNeeded - (userData.level * 100)} XP to next level`, inline: false },
      ],
      footer: { text: `Terus chat untuk mendapat XP!` },
    });

    await interaction.reply({ embeds: [embed] });
  },
};
