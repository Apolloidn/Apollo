const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed, createEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Verifikasi akun Discord kamu untuk mendapat akses penuh'),

  async execute(interaction) {
    const VERIFIED_ROLE_ID = '1437602180076142633';
    const member = interaction.member;

    try {
      if (member.roles.cache.has(VERIFIED_ROLE_ID)) {
        return interaction.reply({
          embeds: [infoEmbed('✅ Sudah Terverifikasi', 'Kamu sudah memiliki role verified!')],
          ephemeral: true
        });
      }

      const accountAge = Date.now() - interaction.user.createdTimestamp;
      const minAccountAge = 7 * 24 * 60 * 60 * 1000;

      if (accountAge < minAccountAge) {
        const daysOld = Math.floor(accountAge / (24 * 60 * 60 * 1000));
        return interaction.reply({
          embeds: [errorEmbed(`⚠️ Akun kamu terlalu baru!\n\nAkun Discord kamu baru berumur **${daysOld} hari**.\nMinimal umur akun: **7 hari**.\n\nSilakan coba lagi nanti atau hubungi staff untuk verifikasi manual.`)],
          ephemeral: true
        });
      }

      const verifyButton = new ButtonBuilder()
        .setCustomId('verify_button')
        .setLabel('✅ Saya Bukan Robot')
        .setStyle(ButtonStyle.Success)
        .setEmoji('🤖');

      const row = new ActionRowBuilder().addComponents(verifyButton);

      const embed = createEmbed({
        color: '#FFA500',
        title: '🔐 Verifikasi Akun',
        description: `Halo ${interaction.user}!\n\nUntuk mendapat akses penuh ke server, silakan klik button di bawah untuk membuktikan kamu bukan robot.\n\n**Umur Akun:** ${Math.floor(accountAge / (24 * 60 * 60 * 1000))} hari ✅\n**Status:** Menunggu verifikasi...`,
        footer: { text: 'Klik button dalam 60 detik' },
      });

      const response = await interaction.reply({
        embeds: [embed],
        components: [row],
        ephemeral: true,
        fetchReply: true
      });

      const collector = response.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 60000,
        max: 1
      });

      collector.on('collect', async (i) => {
        if (i.user.id !== interaction.user.id) {
          await i.reply({ content: '❌ Button ini bukan untuk kamu!', ephemeral: true });
          return;
        }

        try {
          const role = await interaction.guild.roles.fetch(VERIFIED_ROLE_ID);
          if (!role) {
            await i.update({
              embeds: [errorEmbed('Role verified tidak ditemukan di server ini!')],
              components: []
            });
            return;
          }

          await member.roles.add(role);

          const successEmb = createEmbed({
            color: '#00FF00',
            title: '✅ Verifikasi Berhasil!',
            description: `Selamat ${interaction.user}! Kamu telah terverifikasi.\n\n**Umur Akun:** ${Math.floor(accountAge / (24 * 60 * 60 * 1000))} hari\n**Status:** Verified ✅\n\nRole **${role.name}** telah diberikan.\nKamu sekarang punya akses penuh ke server!`,
            footer: { text: 'Terima kasih telah bergabung!' },
          });

          await i.update({ embeds: [successEmb], components: [] });
          console.log(`✅ ${interaction.user.tag} successfully verified (account age: ${Math.floor(accountAge / (24 * 60 * 60 * 1000))} days)`);
        } catch (error) {
          console.error('Error in verify button handler:', error);
          await i.update({
            embeds: [errorEmbed('Terjadi kesalahan saat verifikasi. Silakan coba lagi.')],
            components: []
          }).catch(() => {});
        }
      });

      collector.on('end', async (collected, reason) => {
        if (collected.size === 0 && reason === 'time') {
          const timeoutEmbed = errorEmbed('⏱️ Verifikasi timeout! Silakan jalankan `/verify` lagi.');
          await interaction.editReply({ embeds: [timeoutEmbed], components: [] }).catch(() => {});
        }
      });

    } catch (error) {
      console.error('Error verifying user:', error);
      await interaction.reply({
        embeds: [errorEmbed('Terjadi kesalahan saat memverifikasi. Silakan coba lagi nanti atau hubungi staff.')],
        ephemeral: true
      }).catch(() => {});
    }
  },
};
