const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const QRCode = require('qrcode');
const { errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('qr')
    .setDescription('Generate QR code dari text')
    .addStringOption(option =>
      option.setName('text')
        .setDescription('Text yang akan dijadikan QR code')
        .setRequired(true)
    ),

  async execute(interaction) {
    const text = interaction.options.getString('text');

    try {
      await interaction.deferReply();

      const qrBuffer = await QRCode.toBuffer(text, {
        errorCorrectionLevel: 'H',
        type: 'png',
        width: 512,
      });

      const attachment = new AttachmentBuilder(qrBuffer, { name: 'qrcode.png' });

      await interaction.editReply({
        content: `✅ QR Code berhasil dibuat untuk: \`${text.substring(0, 100)}${text.length > 100 ? '...' : ''}\``,
        files: [attachment],
      });
    } catch (error) {
      console.error('Error generating QR code:', error);
      await interaction.editReply({ embeds: [errorEmbed('Gagal membuat QR code!')] });
    }
  },
};
