const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embedBuilder');
const { reviews } = require('../../utils/storage');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('review')
    .setDescription('Beri rating dan feedback untuk server')
    .addIntegerOption(option =>
      option.setName('rating')
        .setDescription('Rating (1-5 bintang)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(5)
    )
    .addStringOption(option =>
      option.setName('feedback')
        .setDescription('Feedback kamu')
        .setRequired(true)
    ),

  async execute(interaction) {
    const rating = interaction.options.getInteger('rating');
    const feedback = interaction.options.getString('feedback');

    try {
      reviews.add(interaction.user.id, interaction.guild.id, rating, feedback);

      const stars = '⭐'.repeat(rating);
      
      await interaction.reply({ 
        embeds: [successEmbed(`✅ Terima kasih atas review nya!\n\n**Rating:** ${stars} (${rating}/5)\n**Feedback:** ${feedback}`)],
        ephemeral: true
      });
    } catch (error) {
      console.error('Error saving review:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal menyimpan review!')], 
        ephemeral: true 
      });
    }
  },
};
