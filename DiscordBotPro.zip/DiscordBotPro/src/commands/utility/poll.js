const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Buat polling')
    .addStringOption(option =>
      option.setName('question')
        .setDescription('Pertanyaan polling')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('option1')
        .setDescription('Pilihan 1')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('option2')
        .setDescription('Pilihan 2')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('option3')
        .setDescription('Pilihan 3')
        .setRequired(false)
    )
    .addStringOption(option =>
      option.setName('option4')
        .setDescription('Pilihan 4')
        .setRequired(false)
    ),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const options = [
      interaction.options.getString('option1'),
      interaction.options.getString('option2'),
      interaction.options.getString('option3'),
      interaction.options.getString('option4'),
    ].filter(opt => opt !== null);

    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
    
    const description = options
      .map((opt, index) => `${emojis[index]} ${opt}`)
      .join('\n\n');

    const embed = createEmbed({
      color: '#5865F2',
      title: '📊 Poll',
      description: `**${question}**\n\n${description}`,
      footer: { text: `Poll dibuat oleh ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() },
    });

    const message = await interaction.reply({ embeds: [embed], fetchReply: true });

    for (let i = 0; i < options.length; i++) {
      await message.react(emojis[i]);
    }
  },
};
