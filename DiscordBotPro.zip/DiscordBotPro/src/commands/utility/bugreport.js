const { SlashCommandBuilder } = require('discord.js');
const { createEmbed, successEmbed, errorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bugreport')
    .setDescription('Laporkan bug yang kamu temukan')
    .addStringOption(option =>
      option.setName('bug')
        .setDescription('Deskripsi bug')
        .setRequired(true)
    ),

  async execute(interaction) {
    const bug = interaction.options.getString('bug');
    const REPORT_CHANNEL_ID = '1440139961394397395';

    try {
      const channel = await interaction.client.channels.fetch(REPORT_CHANNEL_ID);
      
      if (!channel) {
        return interaction.reply({ 
          embeds: [errorEmbed('Channel bug report tidak ditemukan!')], 
          ephemeral: true 
        });
      }

      const embed = createEmbed({
        color: '#FF0000',
        title: '🐛 Bug Report',
        description: bug,
        fields: [
          { name: '👤 Dilaporkan oleh', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
          { name: '📅 Waktu', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
          { name: '📍 Channel', value: `${interaction.channel.name}`, inline: true },
        ],
        footer: { text: `Server: ${interaction.guild.name}` },
      });

      await channel.send({ embeds: [embed] });

      await interaction.reply({ 
        embeds: [successEmbed('✅ Bug report kamu telah dikirim! Tim kami akan segera memeriksa.')], 
        ephemeral: true 
      });
    } catch (error) {
      console.error('Error sending bug report:', error);
      await interaction.reply({ 
        embeds: [errorEmbed('Gagal mengirim bug report!')], 
        ephemeral: true 
      });
    }
  },
};
