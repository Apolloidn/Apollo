const { Events } = require('discord.js');

const joinTimes = new Map();
const RAID_THRESHOLD = 5;
const RAID_WINDOW = 10000;

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    const now = Date.now();
    const guildId = member.guild.id;

    if (!joinTimes.has(guildId)) {
      joinTimes.set(guildId, []);
    }

    const times = joinTimes.get(guildId);
    times.push({ userId: member.id, timestamp: now });

    times.forEach((entry, index) => {
      if (now - entry.timestamp > RAID_WINDOW) {
        times.splice(index, 1);
      }
    });

    const recentJoins = times.filter(entry => now - entry.timestamp < RAID_WINDOW);

    if (recentJoins.length >= RAID_THRESHOLD) {
      console.log(`⚠️ Possible raid detected in ${member.guild.name}! ${recentJoins.length} members joined in ${RAID_WINDOW}ms`);

      const accountAge = now - member.user.createdTimestamp;
      const oneDayInMs = 24 * 60 * 60 * 1000;

      if (accountAge < oneDayInMs * 7) {
        try {
          await member.send('⚠️ Maaf, server sedang dalam mode proteksi anti-raid. Akun kamu terlalu baru. Silakan coba lagi nanti.');
          await member.kick('Anti-raid protection: Account too new during raid');
          console.log(`🛡️ Kicked ${member.user.tag} (account age: ${Math.floor(accountAge / oneDayInMs)} days)`);
        } catch (error) {
          console.error('Error kicking member during raid protection:', error);
        }
      }
    }

    const VERIFY_CHANNEL_ID = '1440141025241862195';
    const verifyChannel = member.guild.channels.cache.get(VERIFY_CHANNEL_ID);
    
    if (verifyChannel) {
      try {
        await verifyChannel.send(
          `👋 Selamat datang ${member}! Silakan gunakan command \`/verify\` untuk mendapat akses penuh ke server.`
        ).then(msg => {
          setTimeout(() => msg.delete().catch(() => {}), 60000);
        });
      } catch (error) {
        console.error('Error sending welcome message:', error);
      }
    }
  },
};
