const { Events } = require('discord.js');
const { handleError } = require('../utils/errorHandler');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);

    if (!command) {
      console.error(`❌ No command matching ${interaction.commandName} was found.`);
      return;
    }

    try {
      await command.execute(interaction);
      console.log(`✅ ${interaction.user.tag} used /${interaction.commandName}`);
    } catch (error) {
      console.error(`❌ Error executing ${interaction.commandName}:`, error);
      await handleError(interaction, error);
    }
  },
};
