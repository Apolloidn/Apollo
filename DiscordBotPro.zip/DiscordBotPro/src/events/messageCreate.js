const { Events } = require('discord.js');
const { levels } = require('../utils/storage');

const cooldowns = new Map();

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot) return;
    if (!message.guild) return;

    const greetings = ['halo', 'hello', 'hai', 'hi'];
    const content = message.content.toLowerCase();

    if (greetings.some(greeting => content === greeting)) {
      const responses = [
        `Halo ${message.author}! 👋 Ada yang bisa saya bantu?`,
        `Hai ${message.author}! 😊 Selamat datang! Butuh bantuan?`,
        `Hello ${message.author}! ✨ Senang bertemu denganmu!`,
        `Hai ${message.author}! 🎉 Apa kabar? Ada yang bisa dibantu?`,
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      await message.reply(randomResponse);
    }

    const userId = message.author.id;
    const cooldownKey = `${message.guild.id}-${userId}`;
    const now = Date.now();
    const cooldownAmount = 60000;

    if (cooldowns.has(cooldownKey)) {
      const expirationTime = cooldowns.get(cooldownKey) + cooldownAmount;
      if (now < expirationTime) {
        return;
      }
    }

    cooldowns.set(cooldownKey, now);
    setTimeout(() => cooldowns.delete(cooldownKey), cooldownAmount);

    const result = levels.addXP(userId, message.guild.id, Math.floor(Math.random() * 10) + 10);

    if (result.leveledUp) {
      const levelUpMessages = [
        `🎉 Selamat ${message.author}! Kamu naik ke level **${result.newLevel}**!`,
        `✨ Level Up! ${message.author} sekarang level **${result.newLevel}**!`,
        `🚀 Wow! ${message.author} mencapai level **${result.newLevel}**!`,
      ];
      const randomMessage = levelUpMessages[Math.floor(Math.random() * levelUpMessages.length)];
      
      message.channel.send(randomMessage).then(msg => {
        setTimeout(() => msg.delete().catch(() => {}), 10000);
      }).catch(() => {});
    }
  },
};
