const { EmbedBuilder } = require('discord.js');

async function handleError(interaction, error) {
  const errorEmbed = new EmbedBuilder()
    .setColor('#FF0000')
    .setTitle('❌ Error')
    .setDescription('Maaf, terjadi kesalahan saat menjalankan command ini.')
    .setTimestamp();

  const replyOptions = { embeds: [errorEmbed], ephemeral: true };

  try {
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(replyOptions);
    } else {
      await interaction.reply(replyOptions);
    }
  } catch (err) {
    console.error('Failed to send error message:', err);
  }
}

module.exports = { handleError };
