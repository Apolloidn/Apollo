const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../../data');
const WARNINGS_FILE = path.join(DATA_DIR, 'warnings.json');
const LEVELS_FILE = path.join(DATA_DIR, 'levels.json');
const TICKETS_FILE = path.join(DATA_DIR, 'tickets.json');
const REVIEWS_FILE = path.join(DATA_DIR, 'reviews.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function loadData(file) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, '{}');
    return {};
  }
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    console.error(`Error loading ${file}:`, error);
    return {};
  }
}

function saveData(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error(`Error saving ${file}:`, error);
  }
}

const warnings = {
  get: () => loadData(WARNINGS_FILE),
  save: (data) => saveData(WARNINGS_FILE, data),
  add: (userId, guildId, reason, moderator) => {
    const data = warnings.get();
    const key = `${guildId}-${userId}`;
    if (!data[key]) data[key] = [];
    data[key].push({
      reason,
      moderator,
      timestamp: Date.now(),
    });
    warnings.save(data);
    return data[key].length;
  },
  getUser: (userId, guildId) => {
    const data = warnings.get();
    const key = `${guildId}-${userId}`;
    return data[key] || [];
  },
  clear: (userId, guildId) => {
    const data = warnings.get();
    const key = `${guildId}-${userId}`;
    delete data[key];
    warnings.save(data);
  },
};

const levels = {
  get: () => loadData(LEVELS_FILE),
  save: (data) => saveData(LEVELS_FILE, data),
  addXP: (userId, guildId, amount = 10) => {
    const data = levels.get();
    const key = `${guildId}-${userId}`;
    if (!data[key]) {
      data[key] = { xp: 0, level: 0, messages: 0 };
    }
    data[key].xp += amount;
    data[key].messages += 1;
    
    const oldLevel = data[key].level;
    const newLevel = Math.floor(data[key].xp / 100);
    data[key].level = newLevel;
    
    levels.save(data);
    return { leveledUp: newLevel > oldLevel, newLevel, xp: data[key].xp };
  },
  getUser: (userId, guildId) => {
    const data = levels.get();
    const key = `${guildId}-${userId}`;
    return data[key] || { xp: 0, level: 0, messages: 0 };
  },
};

const tickets = {
  get: () => loadData(TICKETS_FILE),
  save: (data) => saveData(TICKETS_FILE, data),
  create: (channelId, userId, type = 'order') => {
    const data = tickets.get();
    data[channelId] = {
      userId,
      type,
      claimed: false,
      claimedBy: null,
      createdAt: Date.now(),
    };
    tickets.save(data);
  },
  claim: (channelId, moderatorId) => {
    const data = tickets.get();
    if (data[channelId]) {
      data[channelId].claimed = true;
      data[channelId].claimedBy = moderatorId;
      tickets.save(data);
      return true;
    }
    return false;
  },
  get: (channelId) => {
    const data = tickets.get();
    return data[channelId] || null;
  },
  delete: (channelId) => {
    const data = tickets.get();
    delete data[channelId];
    tickets.save(data);
  },
};

const reviews = {
  get: () => loadData(REVIEWS_FILE),
  save: (data) => saveData(REVIEWS_FILE, data),
  add: (userId, guildId, rating, feedback) => {
    const data = reviews.get();
    const key = guildId;
    if (!data[key]) data[key] = [];
    data[key].push({
      userId,
      rating,
      feedback,
      timestamp: Date.now(),
    });
    reviews.save(data);
  },
  getAll: (guildId) => {
    const data = reviews.get();
    return data[guildId] || [];
  },
};

module.exports = { warnings, levels, tickets, reviews };
