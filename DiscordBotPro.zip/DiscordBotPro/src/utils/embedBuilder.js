const { EmbedBuilder } = require('discord.js');

function createEmbed(options = {}) {
  const embed = new EmbedBuilder()
    .setColor(options.color || '#0099ff')
    .setTimestamp();

  if (options.title) embed.setTitle(options.title);
  if (options.description) embed.setDescription(options.description);
  if (options.thumbnail) embed.setThumbnail(options.thumbnail);
  if (options.image) embed.setImage(options.image);
  if (options.footer) embed.setFooter(options.footer);
  if (options.author) embed.setAuthor(options.author);
  if (options.fields) embed.addFields(options.fields);

  return embed;
}

function successEmbed(description) {
  return createEmbed({
    color: '#00FF00',
    title: '✅ Success',
    description,
  });
}

function errorEmbed(description) {
  return createEmbed({
    color: '#FF0000',
    title: '❌ Error',
    description,
  });
}

function infoEmbed(title, description) {
  return createEmbed({
    color: '#0099ff',
    title,
    description,
  });
}

module.exports = { createEmbed, successEmbed, errorEmbed, infoEmbed };
