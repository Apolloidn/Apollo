function log(type, message) {
  const timestamp = new Date().toISOString();
  const prefix = {
    info: '📝',
    success: '✅',
    error: '❌',
    warning: '⚠️',
    debug: '🐛',
  };

  console.log(`[${timestamp}] ${prefix[type] || '📝'} ${message}`);
}

module.exports = {
  info: (msg) => log('info', msg),
  success: (msg) => log('success', msg),
  error: (msg) => log('error', msg),
  warning: (msg) => log('warning', msg),
  debug: (msg) => log('debug', msg),
};
