# Discord Bot Professional

## Overview
A professional Discord bot built with Node.js and discord.js v14, featuring a modular command handler system, automatic slash command registration, leveling system, warning system, anti-raid protection, and comprehensive moderation tools.

## Recent Changes
- **2024-11-18**: Major feature expansion
  - Added 16 new commands (total: 28 commands)
  - Implemented JSON-based storage system for persistent data
  - Created leveling system with XP tracking
  - Added warning system with persistent storage
  - Implemented anti-raid protection
  - Created verification system (account age + button)
  - Added QR code generation command
  - Implemented suggestion/bug report system
  - Added server review/rating system
  - Enhanced moderation tools (mute, purge, lock/unlock)

## Project Architecture

### Folder Structure
```
├── index.js                 # Main entry point
├── src/
│   ├── commands/           # Command modules (28 total)
│   │   ├── basic/          # Basic commands (5): ping, help, serverinfo, userinfo, avatar
│   │   ├── moderation/     # Moderation commands (9): kick, ban, warn, warnings, clearwarn, mute, unmute, purge, lock, unlock
│   │   ├── fun/            # Fun commands (3): 8ball, roll, coinflip
│   │   └── utility/        # Utility commands (11): poll, uptime, botinfo, serverstats, qr, suggest, bugreport, review, verify, level
│   ├── events/             # Event handlers
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   ├── messageCreate.js      # Includes leveling system
│   │   └── guildMemberAdd.js     # Includes anti-raid protection
│   └── utils/              # Utility helpers
│       ├── errorHandler.js
│       ├── embedBuilder.js
│       ├── logger.js
│       └── storage.js            # JSON storage manager
├── data/                   # JSON data storage (gitignored)
│   ├── warnings.json
│   ├── levels.json
│   ├── tickets.json
│   └── reviews.json
├── package.json
└── .env                    # Environment variables
```

### Key Features
1. **Automatic Command Registration**: Commands are automatically registered to Discord on bot startup
2. **Modular Command System**: Easy to add new commands - just create a new file in src/commands/
3. **Event Handler System**: Organized event handling with separate files
4. **Error Handling**: Comprehensive error handling for all commands
5. **Auto-Reply**: Bot responds to greetings like "halo", "hello", etc.
6. **Leveling System**: Users gain XP per message, level up automatically
7. **Warning System**: Persistent warning tracking with JSON storage
8. **Anti-Raid Protection**: Detects and prevents mass bot joins
9. **Verification System**: Account age check + button verification
10. **Storage System**: JSON-based persistent storage for all data

## Available Commands

### Basic Commands (5)
- `/ping` - Check bot latency
- `/serverinfo` - Display server information
- `/userinfo` - Display user information  
- `/avatar` - Show user's avatar
- `/help` - Show all available commands

### Moderation Commands (9)
- `/kick` - Kick a member from the server
- `/ban` - Ban a member from the server
- `/warn` - Warn a member (saved to JSON)
- `/warnings` - View user's warning history
- `/clearwarn` - Clear all user warnings
- `/mute` - Mute member with duration
- `/unmute` - Remove member timeout
- `/purge` - Delete messages in bulk (1-100)
- `/lock` - Lock channel (disable sending messages)
- `/unlock` - Unlock channel

### Fun Commands (3)
- `/8ball` - Ask the magic 8-ball
- `/roll` - Roll a dice (customizable sides)
- `/coinflip` - Flip a coin

### Utility Commands (11)
- `/poll` - Create a poll with up to 4 options
- `/uptime` - Show bot uptime
- `/botinfo` - Display bot information
- `/serverstats` - Show detailed server statistics
- `/qr` - Generate QR code from text
- `/suggest` - Send suggestion to channel 1440139961394397395
- `/bugreport` - Report bugs to channel 1440139961394397395
- `/review` - Rate server (1-5 stars) with feedback
- `/verify` - Verify account (7-day age + button verification)
- `/level` - View your level and XP progress

## Systems

### Leveling System
- Users gain 10-20 random XP per message
- 1-minute cooldown between XP gains
- Level up every 100 XP
- Data saved to `data/levels.json`
- Auto-announces level ups (deleted after 10 seconds)
- Progress bar shows XP to next level

### Warning System
- Staff can warn users with `/warn <user> <reason>`
- Warnings saved persistently to `data/warnings.json`
- Includes timestamp, moderator, and reason
- View warnings with `/warnings <user>`
- Clear all warnings with `/clearwarn <user>` (Admin only)
- DM notifications sent to warned users

### Anti-Raid Protection
- Detects if 5+ members join within 10 seconds
- Auto-kicks accounts younger than 7 days during raids
- Protects server from mass bot joins
- Logs all raid protection actions

### Verification System
- **Account Age Check**: Account must be at least 7 days old
- **Button Verification**: User must click "I'm not a robot" button
- **Timeout**: 60 seconds to complete verification
- **Auto-Role**: Assigns role ID 1437602180076142633 on success
- **Welcome Message**: Posted in channel 1440141025241862195

### Review System
- Users can rate server 1-5 stars
- Include feedback text
- Saved to `data/reviews.json` with timestamp

### Storage System
All data is stored in JSON files with proper guild segmentation:
- Key format: `{guildId}-{userId}` prevents data leakage across servers
- Automatic file creation and management
- Error handling for corrupted files

## Configuration

### Role IDs
- **Verified Role**: `1437602180076142633` (assigned by /verify)
- **Staff Role**: `1437602138854391850` (required for /mute, /unmute)

### Channel IDs
- **Suggestion/Bug Report Channel**: `1440139961394397395`
- **Verify Welcome Channel**: `1440141025241862195`

## How to Add New Commands

Creating new commands is super easy:

1. **Create a new file** in the appropriate folder (`src/commands/basic/`, `src/commands/moderation/`, etc.)

2. **Use this template**:
```javascript
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('commandname')
    .setDescription('Command description'),

  async execute(interaction) {
    // Your command logic here
    await interaction.reply('Response!');
  },
};
```

3. **Restart the bot** - The command will be automatically loaded and registered!

## Environment Variables

Required environment variables (set in Replit Secrets):
- `DISCORD_TOKEN` - Your Discord bot token
- `CLIENT_ID` - Your Discord application client ID

## Dependencies
- `discord.js` v14.14.1 - Discord API wrapper
- `dotenv` v16.3.1 - Environment variable management
- `qrcode` v1.5.3 - QR code generation
- `moment` v2.30.1 - Date/time handling

## User Preferences
None specified yet.

## Notes
- Bot uses Discord.js v14 with slash commands
- All commands have comprehensive error handling
- Data persisted across restarts using JSON files
- Anti-raid protection runs automatically
- Leveling system tracks all messages (1-minute cooldown)
- Verification requires both account age AND button interaction
